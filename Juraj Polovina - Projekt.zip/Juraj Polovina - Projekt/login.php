<?php
$error = 0;

if(isset($_POST['login'])){
    //prihvati samo slova
    $username = preg_replace('/[^A-Za-z]/', '', $_POST['username']);
    $password = md5($_POST['password']);
    //provjeri postoji li korisnik
    if(file_exists('users/' . $username . '.xml')){
        $xml = new SimpleXMLElement('users/' . $username . '.xml', 0, true);
        //ako user postoji onda je login uspješan i skače se na index.php stranicu
        if($username == 'admin' && $password == $xml->password) {
            session_start();
            $_SESSION['username'] = $username;
            header('Location: index.php');
            die;
        }else{
            if($password == $xml->password){
                session_start();
                $_SESSION['username'] = $username;
                header('Location: index.php');
                die;
            }else{
                $error = 4;
            }
        }
    }
    elseif(!file_exists('users/' . $username . '.xml')){
        $error = 1;
    }
    if(!file_exists('users/' . $username . '.xml')){
        $error = 2;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XML</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <header>
        <nav>
            <a href="index.php">Početna</a>
            <a href="login.php">Prijava</a>
            <a href="registracija.php">Registracija</a>
        </nav>
    </header>
    <main>
        <section>
            <h1>Prijava</h1><br>
            <p>Korisničko ime: <input type="text" name="username" size="20" style="margin-left: 10px;" /></p>
            <p>Lozinka: <input type="password" name="password" size="20" style="margin-left: 55px;" /></p><br>
            <p><input id="submit-btn" type="submit" value="Login" name="login" /> </p>
                            <?php
                                //provjeri ima li errora i ispiši ih ako ih ima
                                if($error == 1){
                                    echo '<p id="error-msg">Korisničko ime i/ili lozinka nije točno</p>';
                                }
                                elseif ($error == 2) {
                                    echo '<p id="error-msg">Korisnik ne postoji. Prije prijave potrebno se registrirati</p>';
                                }
                                elseif ($error == 4) {
                                    echo '<p id="error-msg">Korisničko ime i/ili lozinka nije točno</p>';
                                } 
                            ?>
        </section>
    </main>
    <footer>
        <p>Juraj Polovina 0246094xxx</p>
        <hr>
        <nav>
            <a href="index.php">Početna</a>
            <a href="login.php">Prijava</a>
            <a href="registracija.php">Registracija</a>
        </nav>
    </footer>
</body>

</html>