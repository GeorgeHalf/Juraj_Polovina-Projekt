<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XML</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <header>
        <nav>
            <a href="index.php">Početna</a>
            <a href="login.php">Prijava</a>
            <a href="registracija.php">Registracija</a>
        </nav>
    </header>
    <main>
        <section>
            <h1>Filmovi u ponudi</h1>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <div id="subject-wrapper">
                            <div id="grid-image">
                                <img src="zlocin-u-holivudu.jpg">
                            </div>
                            <div id="grid-text">
                                <?php
                            // Start php code
                            // Load xml file into xml_data variable
                            $xml_data = simplexml_load_file("xml_data.xml") or 
                            die("Error: Object Creation failure");
                            // Use foreach loop to display data and for sub elements access,
                            // We will use children() function
                            $counter = 0;
                            foreach ($xml_data->children() as $data)
                            {
                                if($counter == 0){
                                //display each sub element in xml file
                                echo "<b>Izvorno ime: ", $data->Ime . "</b><br> ";
                                echo "<b>Redatelj: </b> ", $data->Redatelj . "<br> ";
                                echo "<b>Žanr</b>: </b>", $data->Žanr . "<br> ";
                                echo "<b>Glavna uloga : </b>", $data->GlavnaUloga . "<br>";
                                echo "<b>Trajanje filma : </b>", $data->Trajanje . "<br>";
                                echo "------------------------------------";
                                echo "<br>";
                                break;
                                } else {
                                    $counter = $counter + 1;
                                }
                            }
                            ?>
                            <button id="dodaj">Odaberi</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <div id="subject-wrapper">
                            <div id="grid-image">
                                <img src="top-gun-maverick.jpg">
                            </div>
                            <div id="grid-text">
                                <?php
                            // Start php code
                            // Load xml file into xml_data variable
                            $xml_data = simplexml_load_file("xml_data.xml") or 
                            die("Error: Object Creation failure");
                            // Use foreach loop to display data and for sub elements access,
                            // We will use children() function
                            $counter = 0;
                            foreach ($xml_data->children() as $data)
                            {
                                if($counter == 1){
                                //display each sub element in xml file
                                echo "<b>Izvorno ime: ", $data->Ime . "</b><br> ";
                                echo "<b>Redatelj: </b> ", $data->Redatelj . "<br> ";
                                echo "<b>Žanr</b>: </b>", $data->Žanr . "<br> ";
                                echo "<b>Glavna uloga : </b>", $data->GlavnaUloga . "<br>";
                                echo "<b>Trajanje filma : </b>", $data->Trajanje . "<br>";
                                echo "------------------------------------";
                                echo "<br>";
                                break;
                                } else {
                                    $counter = $counter + 1;
                                }
                            }
                            ?>
                            <button id="dodaj">Odaberi</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div id="subject-wrapper">
                        <div id="grid-image">
                            <img src="dr-strange.jpg">
                        </div>
                        <div id="grid-text">
                            <?php
                            // Start php code
                            // Load xml file into xml_data variable
                            $xml_data = simplexml_load_file("xml_data.xml") or 
                            die("Error: Object Creation failure");
                            // Use foreach loop to display data and for sub elements access,
                            // We will use children() function
                            $counter = 0;
                            foreach ($xml_data->children() as $data)
                            {
                                if($counter == 2){
                                //display each sub element in xml file
                                echo "<b>Izvorno ime: ", $data->Ime . "</b><br> ";
                                echo "<b>Redatelj: </b> ", $data->Redatelj . "<br> ";
                                echo "<b>Žanr</b>: </b>", $data->Žanr . "<br> ";
                                echo "<b>Glavna uloga : </b>", $data->GlavnaUloga . "<br>";
                                echo "<b>Trajanje filma : </b>", $data->Trajanje . "<br>";
                                echo "------------------------------------";
                                echo "<br>";
                                break;
                                } else {
                                    $counter = $counter + 1;
                                }
                            }
                            ?>
                            <button id="dodaj">Odaberi</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div id="subject-wrapper">
                        <div id="grid-image">
                            <img src="sonic-2.jpg">
                        </div>
                        <div id="grid-text">
                            <?php
                                // Start php code
                                // Load xml file into xml_data variable
                                $xml_data = simplexml_load_file("xml_data.xml") or 
                                die("Error: Object Creation failure");
                                // Use foreach loop to display data and for sub elements access,
                                // We will use children() function
                                $counter = 0;
                                foreach ($xml_data->children() as $data)
                                {
                                    if($counter == 3){
                                    //display each sub element in xml file
                                    echo "<b>Izvorno ime: ", $data->Ime . "</b><br> ";
                                    echo "<b>Redatelj: </b> ", $data->Redatelj . "<br> ";
                                    echo "<b>Žanr</b>: </b>", $data->Žanr . "<br> ";
                                    echo "<b>Glavna uloga : </b>", $data->GlavnaUloga . "<br>";
                                    echo "<b>Trajanje filma : </b>", $data->Trajanje . "<br>";
                                    echo "------------------------------------";
                                    echo "<br>";
                                    break;
                                    } else {
                                        $counter = $counter + 1;
                                    }
                                }
                                ?>
                                <button id="dodaj">Odaberi</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div id="subject-wrapper">
                        <div id="grid-image">
                            <img src="jurski-svjet-dominion.jpg">
                        </div>
                        <div id="grid-text">
                            <?php
                            // Start php code
                            // Load xml file into xml_data variable
                            $xml_data = simplexml_load_file("xml_data.xml") or 
                            die("Error: Object Creation failure");
                            // Use foreach loop to display data and for sub elements access,
                            // We will use children() function
                            $counter = 0;
                            foreach ($xml_data->children() as $data)
                            {
                                if($counter == 4){
                                //display each sub element in xml file
                                echo "<b>Izvorno ime: ", $data->Ime . "</b><br> ";
                                echo "<b>Redatelj: </b> ", $data->Redatelj . "<br> ";
                                echo "<b>Žanr</b>: </b>", $data->Žanr . "<br> ";
                                echo "<b>Glavna uloga : </b>", $data->GlavnaUloga . "<br>";
                                echo "<b>Trajanje filma : </b>", $data->Trajanje . "<br>";
                                echo "------------------------------------";
                                echo "<br>";
                                break;
                                } else {
                                    $counter = $counter + 1;
                                }
                            }
                            ?>
                            <button id="dodaj">Odaberi</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div id="subject-wrapper">
                        <div id="grid-image">
                            <img src="sjecanja-ubojice.jpg">
                        </div>
                        <div id="grid-text">
                            <?php
                            // Start php code
                            // Load xml file into xml_data variable
                            $xml_data = simplexml_load_file("xml_data.xml") or 
                            die("Error: Object Creation failure");
                            // Use foreach loop to display data and for sub elements access,
                            // We will use children() function
                            $counter = 0;
                            foreach ($xml_data->children() as $data)
                            {
                                if($counter == 5){
                                //display each sub element in xml file
                                echo "<b>Izvorno ime: ", $data->Ime . "</b><br> ";
                                echo "<b>Redatelj: </b> ", $data->Redatelj . "<br> ";
                                echo "<b>Žanr</b>: </b>", $data->Žanr . "<br> ";
                                echo "<b>Glavna uloga : </b>", $data->GlavnaUloga . "<br>";
                                echo "<b>Trajanje filma : </b>", $data->Trajanje . "<br>";
                                echo "------------------------------------";
                                echo "<br>";
                                break;
                                } else {
                                    $counter = $counter + 1;
                                }
                            }
                            ?>
                            <button id="dodaj">Odaberi</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div id="subject-wrapper">
                        <div id="grid-image">
                            <img src="crni-telefon.jpg">
                        </div>
                        <div id="grid-text">
                            <?php
                            // Start php code
                            // Load xml file into xml_data variable
                            $xml_data = simplexml_load_file("xml_data.xml") or 
                            die("Error: Object Creation failure");
                            // Use foreach loop to display data and for sub elements access,
                            // We will use children() function
                            $counter = 0;
                            foreach ($xml_data->children() as $data)
                            {
                                if($counter == 6){
                                //display each sub element in xml file
                                echo "<b>Izvorno ime: ", $data->Ime . "</b><br> ";
                                echo "<b>Redatelj: </b> ", $data->Redatelj . "<br> ";
                                echo "<b>Žanr</b>: </b>", $data->Žanr . "<br> ";
                                echo "<b>Glavna uloga : </b>", $data->GlavnaUloga . "<br>";
                                echo "<b>Trajanje filma : </b>", $data->Trajanje . "<br>";
                                echo "------------------------------------";
                                echo "<br>";
                                break;
                                } else {
                                    $counter = $counter + 1;
                                }
                            }
                            ?>
                            <button id="dodaj">Odaberi</button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div id="subject-wrapper">
                        <div id="grid-image">
                            <img src="buzzlightyear.jpg">
                        </div>
                        <div id="grid-text">
                            <?php
                            // Start php code
                            // Load xml file into xml_data variable
                            $xml_data = simplexml_load_file("xml_data.xml") or 
                            die("Error: Object Creation failure");
                            // Use foreach loop to display data and for sub elements access,
                            // We will use children() function
                            $counter = 0;
                            foreach ($xml_data->children() as $data)
                            {
                                if($counter == 7){
                                //display each sub element in xml file
                                echo "<b>Izvorno ime: ", $data->Ime . "</b><br> ";
                                echo "<b>Redatelj: </b> ", $data->Redatelj . "<br> ";
                                echo "<b>Žanr</b>: </b>", $data->Žanr . "<br> ";
                                echo "<b>Glavna uloga : </b>", $data->GlavnaUloga . "<br>";
                                echo "<b>Trajanje filma : </b>", $data->Trajanje . "<br>";
                                echo "------------------------------------";
                                echo "<br>";
                                break;
                                } else {
                                    $counter = $counter + 1;
                                }
                            }
                            ?>
                            <button id="dodaj">Odaberi</button>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>
    </main>
    <footer>
        <p>Juraj Polovina 0246094xxx</p>
        <hr>
        <nav>
            <a href="index.php">Početna</a>
            <a href="login.php">Prijava</a>
            <a href="registracija.php">Registracija</a>
        </nav>
    </footer>
</body>

</html>