<?php
//polje sa errorima 
$errors = array();
if(isset($_POST['login'])){
    //preg_replace služi da se uzimaju u obzir samo slova A-Z i a-z
    $username = preg_replace('/[^A-Za-z]/', '', $_POST['username']);
    $email = $_POST['email'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];
    //provjeri postoji li već username
    if(file_exists('users/' . $username . '.xml')){
        $errors[] = 'Korisnik već postoji';
    }
    //errori
    if($username == ''){
        $errors[] = 'Korisničko ime je prazno';
    }
    if($email == ''){
        $errors[] = 'Email nije upisan';
    }
    if($password == '' || $c_password == ''){
        $errors[] = 'Lozinke nisu upisane';
    }
    if($password != $c_password){
        $errors[] = 'Lozinke se ne poklapaju';
    }
    //ako nema errora, onda dodaj usera u xml file sa strukturom <username><password></password><email></email></username>
    if(count($errors) == 0){
        $xml = new SimpleXMLElement('<user></user>');
        $xml->addChild('password', md5($password));
        $xml->addChild('email', $email);
        $xml->asXML('users/' . $username . '.xml');
        header('Location: login.php');
        die;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>XML</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <header>
        <nav>
            <a href="index.php">Početna</a>
            <a href="login.php">Prijava</a>
            <a href="registracija.php">Registracija</a>
        </nav>
    </header>
    <main>
        <section>
            <h1>Registracija</h1><br>
            <div id="form-wrapper">
                <form method="post" action="">
                        <p style="margin-left: 70px;">Username: <input type="text" name="username" size="20"  /></p>
                        <p style="margin-left: 110px;">Email: <input type="text" name="email" size="20" /></p>
                        <p style="margin-left: 75px;">Password: <input type="password" name="password" size="20" /></p>
                        <p style="margin-left: 5px;">Confirm Password: <input type="password" name="c_password" size="20" /></p><br>
                        <p><input id="submit-btn" type="submit" value="Register" name="login" /> </p>
                        <?php
                            //ispis errora
                            if(count($errors) > 0){
                                echo '<ul id="error-msg">';
                                foreach($errors as $e){
                                    echo '<li id="error-msg" style="list-style-type: none; margin-left: 150px;"> - ' . $e . '!</li>';
                                }
                                echo '</ul>';
                            }
                        ?>
                    </div>
                </form>
            </div>
        </section>
    </main>
    <footer>
        <p>Juraj Polovina 0246094xxx</p>
        <hr>
        <nav>
            <a href="index.php">Početna</a>
            <a href="login.php">Prijava</a>
            <a href="registracija.php">Registracija</a>
        </nav>
    </footer>
</body>

</html>